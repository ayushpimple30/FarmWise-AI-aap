// Text-to-Speech utilities for AgroSahayak

import { Language } from './i18n';

// Language to BCP 47 locale mapping
const LANGUAGE_VOICES: Record<Language, string[]> = {
  en: ['en-IN', 'en-US', 'en-GB'],
  hi: ['hi-IN'],
  mr: ['mr-IN', 'hi-IN'], // Fallback to Hindi if Marathi not available
};

let currentUtterance: SpeechSynthesisUtterance | null = null;
let isSpeaking = false;

// Check if TTS is supported
export function isTTSSupported(): boolean {
  return 'speechSynthesis' in window;
}

// Get available voices for a language
export function getVoicesForLanguage(lang: Language): SpeechSynthesisVoice[] {
  if (!isTTSSupported()) return [];
  
  const voices = window.speechSynthesis.getVoices();
  const preferredLocales = LANGUAGE_VOICES[lang];
  
  // Find voices matching preferred locales
  const matchingVoices: SpeechSynthesisVoice[] = [];
  
  for (const locale of preferredLocales) {
    const found = voices.filter(v => v.lang.startsWith(locale.split('-')[0]));
    matchingVoices.push(...found);
  }
  
  return matchingVoices;
}

// Speak text
export function speak(text: string, lang: Language): Promise<void> {
  return new Promise((resolve, reject) => {
    if (!isTTSSupported()) {
      reject(new Error('TTS not supported'));
      return;
    }
    
    // Stop any current speech
    stop();
    
    const utterance = new SpeechSynthesisUtterance(text);
    currentUtterance = utterance;
    
    // Set language
    const locales = LANGUAGE_VOICES[lang];
    utterance.lang = locales[0];
    
    // Try to find a matching voice
    const voices = window.speechSynthesis.getVoices();
    for (const locale of locales) {
      const voice = voices.find(v => v.lang === locale || v.lang.startsWith(locale.split('-')[0]));
      if (voice) {
        utterance.voice = voice;
        utterance.lang = voice.lang;
        break;
      }
    }
    
    // Set speech parameters for clarity
    utterance.rate = 0.9; // Slightly slower for better understanding
    utterance.pitch = 1;
    utterance.volume = 1;
    
    utterance.onstart = () => {
      isSpeaking = true;
    };
    
    utterance.onend = () => {
      isSpeaking = false;
      currentUtterance = null;
      resolve();
    };
    
    utterance.onerror = (event) => {
      isSpeaking = false;
      currentUtterance = null;
      reject(new Error(event.error));
    };
    
    window.speechSynthesis.speak(utterance);
  });
}

// Stop speaking
export function stop(): void {
  if (isTTSSupported()) {
    window.speechSynthesis.cancel();
    isSpeaking = false;
    currentUtterance = null;
  }
}

// Pause speaking
export function pause(): void {
  if (isTTSSupported() && isSpeaking) {
    window.speechSynthesis.pause();
  }
}

// Resume speaking
export function resume(): void {
  if (isTTSSupported()) {
    window.speechSynthesis.resume();
  }
}

// Check if currently speaking
export function getIsSpeaking(): boolean {
  return isSpeaking;
}

// Initialize voices (call on app load)
export function initializeVoices(): Promise<SpeechSynthesisVoice[]> {
  return new Promise((resolve) => {
    if (!isTTSSupported()) {
      resolve([]);
      return;
    }
    
    let voices = window.speechSynthesis.getVoices();
    
    if (voices.length > 0) {
      resolve(voices);
      return;
    }
    
    // Wait for voices to load
    window.speechSynthesis.onvoiceschanged = () => {
      voices = window.speechSynthesis.getVoices();
      resolve(voices);
    };
    
    // Timeout fallback
    setTimeout(() => {
      resolve(window.speechSynthesis.getVoices());
    }, 1000);
  });
}

// Speak with highlight callback (for guided tour)
export function speakWithCallback(
  text: string,
  lang: Language,
  onWord?: (word: string, charIndex: number) => void
): Promise<void> {
  return new Promise((resolve, reject) => {
    if (!isTTSSupported()) {
      reject(new Error('TTS not supported'));
      return;
    }
    
    stop();
    
    const utterance = new SpeechSynthesisUtterance(text);
    currentUtterance = utterance;
    
    const locales = LANGUAGE_VOICES[lang];
    utterance.lang = locales[0];
    
    const voices = window.speechSynthesis.getVoices();
    for (const locale of locales) {
      const voice = voices.find(v => v.lang === locale || v.lang.startsWith(locale.split('-')[0]));
      if (voice) {
        utterance.voice = voice;
        break;
      }
    }
    
    utterance.rate = 0.85;
    utterance.pitch = 1;
    
    if (onWord) {
      utterance.onboundary = (event) => {
        if (event.name === 'word') {
          const word = text.substring(event.charIndex, event.charIndex + event.charLength);
          onWord(word, event.charIndex);
        }
      };
    }
    
    utterance.onstart = () => {
      isSpeaking = true;
    };
    
    utterance.onend = () => {
      isSpeaking = false;
      currentUtterance = null;
      resolve();
    };
    
    utterance.onerror = (event) => {
      isSpeaking = false;
      currentUtterance = null;
      reject(new Error(event.error));
    };
    
    window.speechSynthesis.speak(utterance);
  });
}
