// Multi-language support for AgroSahayak
export type Language = 'en' | 'hi' | 'mr';

export const translations = {
  en: {
    // App
    appName: 'AgroSahayak',
    tagline: 'Your Smart Farming Companion',
    
    // Navigation
    home: 'Home',
    scan: 'Scan',
    history: 'History',
    weather: 'Weather',
    schemes: 'Schemes',
    settings: 'Settings',
    
    // Home Screen
    welcomeMessage: 'Welcome, Farmer!',
    scanCrop: 'Scan Your Crop',
    scanDescription: 'Take a photo to detect diseases',
    viewHistory: 'View History',
    historyDescription: 'See your previous scans',
    checkWeather: 'Check Weather',
    weatherDescription: 'Get farming weather advice',
    govSchemes: 'Government Schemes',
    schemesDescription: 'Benefits for farmers',
    
    // Scan Screen
    scanTitle: 'Scan Your Crop',
    scanInstruction: 'Point camera at the affected leaf',
    takePhoto: 'Take Photo',
    uploadPhoto: 'Upload Photo',
    analyzing: 'Analyzing...',
    scanTip: 'Tip: Ensure good lighting and focus on the affected area',
    
    // Image Quality Warnings
    tooDark: 'Image is too dark. Please ensure better lighting.',
    tooBlurry: 'Image appears blurry. Please hold steady and refocus.',
    tooFar: 'Leaf appears too small. Please move closer.',
    goodQuality: 'Good image quality!',
    
    // Results Screen
    resultTitle: 'Scan Result',
    crop: 'Crop',
    disease: 'Disease',
    confidence: 'Confidence',
    severity: 'Severity',
    severityLow: 'Low',
    severityMedium: 'Medium',
    severityHigh: 'High',
    treatment: 'Treatment',
    prevention: 'Prevention',
    viewActions: 'View Actions',
    saveResult: 'Save Result',
    scanAgain: 'Scan Again',
    listen: 'Listen',
    stopListening: 'Stop',
    
    // Actions Screen
    actionsTitle: 'Recommended Actions',
    immediateActions: 'Immediate Actions',
    preventiveMeasures: 'Preventive Measures',
    chemicalTreatment: 'Chemical Treatment',
    organicTreatment: 'Organic Options',
    
    // History Screen
    historyTitle: 'Scan History',
    noHistory: 'No scan history yet',
    noHistoryDesc: 'Your crop scan results will appear here',
    deleteHistory: 'Delete',
    viewDetails: 'View Details',
    scannedOn: 'Scanned on',
    
    // Weather Screen
    weatherTitle: 'Weather Forecast',
    currentWeather: 'Current Weather',
    forecast: '5-Day Forecast',
    temperature: 'Temperature',
    humidity: 'Humidity',
    rainfall: 'Rainfall',
    wind: 'Wind',
    farmingAdvice: 'Farming Advice',
    irrigationAdvice: 'Irrigation',
    sprayWarning: 'Spray Warning',
    diseaseRisk: 'Disease Risk',
    offline: 'Offline - Showing cached data',
    
    // Schemes Screen
    schemesTitle: 'Government Schemes',
    pmKisan: 'PM Kisan Samman Nidhi',
    pmKisanDesc: 'Get ₹6,000 per year direct benefit',
    cropInsurance: 'Crop Insurance (PMFBY)',
    cropInsuranceDesc: 'Protect your crops from natural calamities',
    soilHealth: 'Soil Health Card',
    soilHealthDesc: 'Free soil testing and recommendations',
    kisanCallCenter: 'Kisan Call Center',
    kisanCallCenterDesc: 'Call 1800-180-1551 for free farming advice',
    applyNow: 'Apply Now',
    callNow: 'Call Now',
    learnMore: 'Learn More',
    
    // Settings
    settingsTitle: 'Settings',
    language: 'Language',
    english: 'English',
    hindi: 'हिंदी',
    marathi: 'मराठी',
    notifications: 'Notifications',
    about: 'About',
    help: 'Help',
    replayGuide: 'Replay App Guide',
    installApp: 'Install App',
    version: 'Version',
    
    // Onboarding
    onboardingWelcome: 'Welcome to AgroSahayak!',
    onboardingQuestion: 'Would you like a guided tour of the app?',
    yes: 'Yes',
    no: 'No',
    next: 'Next',
    skip: 'Skip',
    finish: 'Finish',
    onboardingStep1: 'This is your home screen. Access all features from here.',
    onboardingStep2: 'Tap here to scan your crops for diseases.',
    onboardingStep3: 'View your scan history and track crop health.',
    onboardingStep4: 'Check weather and get farming advice.',
    onboardingStep5: 'Learn about government schemes for farmers.',
    
    // PWA
    installPrompt: 'Install AgroSahayak',
    installPromptDesc: 'Add to home screen for quick access',
    install: 'Install',
    later: 'Later',
    
    // Common
    loading: 'Loading...',
    error: 'Error',
    retry: 'Retry',
    close: 'Close',
    save: 'Save',
    cancel: 'Cancel',
    confirm: 'Confirm',
    success: 'Success',
    noInternet: 'No internet connection',
  },
  
  hi: {
    // App
    appName: 'एग्रोसहायक',
    tagline: 'आपका स्मार्ट कृषि सहायक',
    
    // Navigation
    home: 'होम',
    scan: 'स्कैन',
    history: 'इतिहास',
    weather: 'मौसम',
    schemes: 'योजनाएं',
    settings: 'सेटिंग्स',
    
    // Home Screen
    welcomeMessage: 'स्वागत है, किसान!',
    scanCrop: 'फसल स्कैन करें',
    scanDescription: 'रोग पता लगाने के लिए फोटो लें',
    viewHistory: 'इतिहास देखें',
    historyDescription: 'अपने पिछले स्कैन देखें',
    checkWeather: 'मौसम देखें',
    weatherDescription: 'कृषि मौसम सलाह प्राप्त करें',
    govSchemes: 'सरकारी योजनाएं',
    schemesDescription: 'किसानों के लिए लाभ',
    
    // Scan Screen
    scanTitle: 'फसल स्कैन करें',
    scanInstruction: 'कैमरा प्रभावित पत्ती पर रखें',
    takePhoto: 'फोटो लें',
    uploadPhoto: 'फोटो अपलोड करें',
    analyzing: 'विश्लेषण हो रहा है...',
    scanTip: 'सुझाव: अच्छी रोशनी और प्रभावित क्षेत्र पर फोकस रखें',
    
    // Image Quality Warnings
    tooDark: 'छवि बहुत अंधेरी है। बेहतर रोशनी सुनिश्चित करें।',
    tooBlurry: 'छवि धुंधली है। स्थिर रहें और पुनः फोकस करें।',
    tooFar: 'पत्ती बहुत छोटी दिख रही है। करीब आएं।',
    goodQuality: 'अच्छी छवि गुणवत्ता!',
    
    // Results Screen
    resultTitle: 'स्कैन परिणाम',
    crop: 'फसल',
    disease: 'रोग',
    confidence: 'विश्वास स्तर',
    severity: 'गंभीरता',
    severityLow: 'कम',
    severityMedium: 'मध्यम',
    severityHigh: 'उच्च',
    treatment: 'उपचार',
    prevention: 'रोकथाम',
    viewActions: 'कार्यवाही देखें',
    saveResult: 'परिणाम सेव करें',
    scanAgain: 'फिर से स्कैन करें',
    listen: 'सुनें',
    stopListening: 'रुकें',
    
    // Actions Screen
    actionsTitle: 'अनुशंसित कार्यवाही',
    immediateActions: 'तुरंत कार्यवाही',
    preventiveMeasures: 'रोकथाम उपाय',
    chemicalTreatment: 'रासायनिक उपचार',
    organicTreatment: 'जैविक विकल्प',
    
    // History Screen
    historyTitle: 'स्कैन इतिहास',
    noHistory: 'अभी तक कोई इतिहास नहीं',
    noHistoryDesc: 'आपके फसल स्कैन परिणाम यहां दिखाई देंगे',
    deleteHistory: 'हटाएं',
    viewDetails: 'विवरण देखें',
    scannedOn: 'स्कैन की तारीख',
    
    // Weather Screen
    weatherTitle: 'मौसम पूर्वानुमान',
    currentWeather: 'वर्तमान मौसम',
    forecast: '5-दिन का पूर्वानुमान',
    temperature: 'तापमान',
    humidity: 'आर्द्रता',
    rainfall: 'वर्षा',
    wind: 'हवा',
    farmingAdvice: 'कृषि सलाह',
    irrigationAdvice: 'सिंचाई',
    sprayWarning: 'स्प्रे चेतावनी',
    diseaseRisk: 'रोग जोखिम',
    offline: 'ऑफलाइन - कैश्ड डेटा दिखा रहे हैं',
    
    // Schemes Screen
    schemesTitle: 'सरकारी योजनाएं',
    pmKisan: 'पीएम किसान सम्मान निधि',
    pmKisanDesc: 'प्रति वर्ष ₹6,000 का सीधा लाभ',
    cropInsurance: 'फसल बीमा (पीएमएफबीवाई)',
    cropInsuranceDesc: 'प्राकृतिक आपदाओं से अपनी फसल की रक्षा करें',
    soilHealth: 'मृदा स्वास्थ्य कार्ड',
    soilHealthDesc: 'मुफ्त मिट्टी परीक्षण और सिफारिशें',
    kisanCallCenter: 'किसान कॉल सेंटर',
    kisanCallCenterDesc: 'मुफ्त कृषि सलाह के लिए 1800-180-1551 पर कॉल करें',
    applyNow: 'अभी आवेदन करें',
    callNow: 'अभी कॉल करें',
    learnMore: 'और जानें',
    
    // Settings
    settingsTitle: 'सेटिंग्स',
    language: 'भाषा',
    english: 'English',
    hindi: 'हिंदी',
    marathi: 'मराठी',
    notifications: 'सूचनाएं',
    about: 'हमारे बारे में',
    help: 'मदद',
    replayGuide: 'ऐप गाइड दोहराएं',
    installApp: 'ऐप इंस्टॉल करें',
    version: 'संस्करण',
    
    // Onboarding
    onboardingWelcome: 'एग्रोसहायक में आपका स्वागत है!',
    onboardingQuestion: 'क्या आप ऐप का गाइडेड टूर चाहते हैं?',
    yes: 'हाँ',
    no: 'नहीं',
    next: 'आगे',
    skip: 'छोड़ें',
    finish: 'समाप्त',
    onboardingStep1: 'यह आपकी होम स्क्रीन है। यहां से सभी सुविधाओं तक पहुंचें।',
    onboardingStep2: 'रोगों के लिए अपनी फसलों को स्कैन करने के लिए यहां टैप करें।',
    onboardingStep3: 'अपना स्कैन इतिहास देखें और फसल स्वास्थ्य ट्रैक करें।',
    onboardingStep4: 'मौसम देखें और कृषि सलाह प्राप्त करें।',
    onboardingStep5: 'किसानों के लिए सरकारी योजनाओं के बारे में जानें।',
    
    // PWA
    installPrompt: 'एग्रोसहायक इंस्टॉल करें',
    installPromptDesc: 'त्वरित पहुंच के लिए होम स्क्रीन पर जोड़ें',
    install: 'इंस्टॉल',
    later: 'बाद में',
    
    // Common
    loading: 'लोड हो रहा है...',
    error: 'त्रुटि',
    retry: 'पुनः प्रयास करें',
    close: 'बंद करें',
    save: 'सेव करें',
    cancel: 'रद्द करें',
    confirm: 'पुष्टि करें',
    success: 'सफल',
    noInternet: 'इंटरनेट कनेक्शन नहीं है',
  },
  
  mr: {
    // App
    appName: 'ॲग्रोसहायक',
    tagline: 'तुमचा स्मार्ट शेती सहायक',
    
    // Navigation
    home: 'होम',
    scan: 'स्कॅन',
    history: 'इतिहास',
    weather: 'हवामान',
    schemes: 'योजना',
    settings: 'सेटिंग्ज',
    
    // Home Screen
    welcomeMessage: 'स्वागत आहे, शेतकरी!',
    scanCrop: 'पीक स्कॅन करा',
    scanDescription: 'रोग शोधण्यासाठी फोटो घ्या',
    viewHistory: 'इतिहास पहा',
    historyDescription: 'तुमचे मागील स्कॅन पहा',
    checkWeather: 'हवामान तपासा',
    weatherDescription: 'शेती हवामान सल्ला मिळवा',
    govSchemes: 'सरकारी योजना',
    schemesDescription: 'शेतकऱ्यांसाठी लाभ',
    
    // Scan Screen
    scanTitle: 'पीक स्कॅन करा',
    scanInstruction: 'कॅमेरा प्रभावित पानावर ठेवा',
    takePhoto: 'फोटो घ्या',
    uploadPhoto: 'फोटो अपलोड करा',
    analyzing: 'विश्लेषण होत आहे...',
    scanTip: 'टीप: चांगला प्रकाश आणि प्रभावित क्षेत्रावर लक्ष केंद्रित करा',
    
    // Image Quality Warnings
    tooDark: 'प्रतिमा खूप गडद आहे. चांगला प्रकाश सुनिश्चित करा.',
    tooBlurry: 'प्रतिमा धूसर दिसत आहे. स्थिर रहा आणि पुन्हा फोकस करा.',
    tooFar: 'पान खूप लहान दिसत आहे. जवळ या.',
    goodQuality: 'चांगली प्रतिमा गुणवत्ता!',
    
    // Results Screen
    resultTitle: 'स्कॅन परिणाम',
    crop: 'पीक',
    disease: 'रोग',
    confidence: 'विश्वास पातळी',
    severity: 'तीव्रता',
    severityLow: 'कमी',
    severityMedium: 'मध्यम',
    severityHigh: 'उच्च',
    treatment: 'उपचार',
    prevention: 'प्रतिबंध',
    viewActions: 'कृती पहा',
    saveResult: 'परिणाम जतन करा',
    scanAgain: 'पुन्हा स्कॅन करा',
    listen: 'ऐका',
    stopListening: 'थांबा',
    
    // Actions Screen
    actionsTitle: 'शिफारस केलेल्या कृती',
    immediateActions: 'तात्काळ कृती',
    preventiveMeasures: 'प्रतिबंधक उपाय',
    chemicalTreatment: 'रासायनिक उपचार',
    organicTreatment: 'सेंद्रिय पर्याय',
    
    // History Screen
    historyTitle: 'स्कॅन इतिहास',
    noHistory: 'अद्याप कोणताही इतिहास नाही',
    noHistoryDesc: 'तुमचे पीक स्कॅन परिणाम येथे दिसतील',
    deleteHistory: 'हटवा',
    viewDetails: 'तपशील पहा',
    scannedOn: 'स्कॅन तारीख',
    
    // Weather Screen
    weatherTitle: 'हवामान अंदाज',
    currentWeather: 'सध्याचे हवामान',
    forecast: '5-दिवसांचा अंदाज',
    temperature: 'तापमान',
    humidity: 'आर्द्रता',
    rainfall: 'पाऊस',
    wind: 'वारा',
    farmingAdvice: 'शेती सल्ला',
    irrigationAdvice: 'सिंचन',
    sprayWarning: 'फवारणी चेतावणी',
    diseaseRisk: 'रोग धोका',
    offline: 'ऑफलाइन - कॅश केलेला डेटा दाखवत आहे',
    
    // Schemes Screen
    schemesTitle: 'सरकारी योजना',
    pmKisan: 'पीएम किसान सन्मान निधी',
    pmKisanDesc: 'दरवर्षी ₹6,000 थेट लाभ मिळवा',
    cropInsurance: 'पीक विमा (पीएमएफबीवाय)',
    cropInsuranceDesc: 'नैसर्गिक आपत्तींपासून तुमच्या पिकांचे संरक्षण करा',
    soilHealth: 'मृदा आरोग्य कार्ड',
    soilHealthDesc: 'मोफत माती चाचणी आणि शिफारसी',
    kisanCallCenter: 'किसान कॉल सेंटर',
    kisanCallCenterDesc: 'मोफत शेती सल्ल्यासाठी 1800-180-1551 वर कॉल करा',
    applyNow: 'आता अर्ज करा',
    callNow: 'आता कॉल करा',
    learnMore: 'अधिक जाणून घ्या',
    
    // Settings
    settingsTitle: 'सेटिंग्ज',
    language: 'भाषा',
    english: 'English',
    hindi: 'हिंदी',
    marathi: 'मराठी',
    notifications: 'सूचना',
    about: 'आमच्याबद्दल',
    help: 'मदत',
    replayGuide: 'ॲप गाइड पुन्हा प्ले करा',
    installApp: 'ॲप इंस्टॉल करा',
    version: 'आवृत्ती',
    
    // Onboarding
    onboardingWelcome: 'ॲग्रोसहायक मध्ये आपले स्वागत आहे!',
    onboardingQuestion: 'तुम्हाला ॲपचा मार्गदर्शित टूर हवा आहे का?',
    yes: 'होय',
    no: 'नाही',
    next: 'पुढे',
    skip: 'वगळा',
    finish: 'पूर्ण',
    onboardingStep1: 'ही तुमची होम स्क्रीन आहे. येथून सर्व वैशिष्ट्यांमध्ये प्रवेश करा.',
    onboardingStep2: 'रोगांसाठी तुमची पिके स्कॅन करण्यासाठी येथे टॅप करा.',
    onboardingStep3: 'तुमचा स्कॅन इतिहास पहा आणि पीक आरोग्य ट्रॅक करा.',
    onboardingStep4: 'हवामान तपासा आणि शेती सल्ला मिळवा.',
    onboardingStep5: 'शेतकऱ्यांसाठी सरकारी योजनांबद्दल जाणून घ्या.',
    
    // PWA
    installPrompt: 'ॲग्रोसहायक इंस्टॉल करा',
    installPromptDesc: 'जलद प्रवेशासाठी होम स्क्रीनवर जोडा',
    install: 'इंस्टॉल करा',
    later: 'नंतर',
    
    // Common
    loading: 'लोड होत आहे...',
    error: 'त्रुटी',
    retry: 'पुन्हा प्रयत्न करा',
    close: 'बंद करा',
    save: 'जतन करा',
    cancel: 'रद्द करा',
    confirm: 'पुष्टी करा',
    success: 'यशस्वी',
    noInternet: 'इंटरनेट कनेक्शन नाही',
  },
};

export type TranslationKey = keyof typeof translations.en;

export function getTranslation(lang: Language, key: TranslationKey): string {
  return translations[lang][key] || translations.en[key] || key;
}

export function t(lang: Language, key: TranslationKey): string {
  return getTranslation(lang, key);
}
