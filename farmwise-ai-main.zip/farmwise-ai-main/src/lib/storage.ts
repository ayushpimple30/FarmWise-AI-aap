// Local storage utilities for AgroSahayak

import { Language } from './i18n';

// Types
export interface ScanResult {
  id: string;
  imageData: string; // Base64 encoded image
  crop: string;
  disease: string;
  confidence: number;
  severity: 'low' | 'medium' | 'high';
  timestamp: number;
  treatments: string[];
  preventions: string[];
}

export interface WeatherCache {
  data: WeatherData | null;
  timestamp: number;
}

export interface WeatherData {
  current: {
    temp: number;
    humidity: number;
    description: string;
    icon: string;
    windSpeed: number;
    rainProbability: number;
  };
  forecast: {
    date: string;
    temp: number;
    minTemp: number;
    maxTemp: number;
    description: string;
    icon: string;
    rainProbability: number;
  }[];
  location: string;
}

export interface AppSettings {
  language: Language;
  hasSeenOnboarding: boolean;
  notificationsEnabled: boolean;
}

const STORAGE_KEYS = {
  SCAN_HISTORY: 'agrosahayak_scan_history',
  WEATHER_CACHE: 'agrosahayak_weather_cache',
  SETTINGS: 'agrosahayak_settings',
};

// Default settings
const DEFAULT_SETTINGS: AppSettings = {
  language: 'en',
  hasSeenOnboarding: false,
  notificationsEnabled: true,
};

// Helper functions
function getItem<T>(key: string, defaultValue: T): T {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : defaultValue;
  } catch {
    return defaultValue;
  }
}

function setItem<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    console.error('Failed to save to localStorage:', error);
  }
}

// Scan History
export function getScanHistory(): ScanResult[] {
  return getItem<ScanResult[]>(STORAGE_KEYS.SCAN_HISTORY, []);
}

export function addScanResult(result: Omit<ScanResult, 'id' | 'timestamp'>): ScanResult {
  const history = getScanHistory();
  const newResult: ScanResult = {
    ...result,
    id: crypto.randomUUID(),
    timestamp: Date.now(),
  };
  history.unshift(newResult); // Add to beginning
  setItem(STORAGE_KEYS.SCAN_HISTORY, history.slice(0, 50)); // Keep last 50 scans
  return newResult;
}

export function deleteScanResult(id: string): void {
  const history = getScanHistory();
  const filtered = history.filter(item => item.id !== id);
  setItem(STORAGE_KEYS.SCAN_HISTORY, filtered);
}

export function getScanResultById(id: string): ScanResult | undefined {
  const history = getScanHistory();
  return history.find(item => item.id === id);
}

export function clearScanHistory(): void {
  setItem(STORAGE_KEYS.SCAN_HISTORY, []);
}

// Weather Cache
export function getWeatherCache(): WeatherCache {
  return getItem<WeatherCache>(STORAGE_KEYS.WEATHER_CACHE, { data: null, timestamp: 0 });
}

export function setWeatherCache(data: WeatherData): void {
  setItem(STORAGE_KEYS.WEATHER_CACHE, { data, timestamp: Date.now() });
}

export function isWeatherCacheValid(): boolean {
  const cache = getWeatherCache();
  const CACHE_DURATION = 30 * 60 * 1000; // 30 minutes
  return cache.data !== null && Date.now() - cache.timestamp < CACHE_DURATION;
}

// Settings
export function getSettings(): AppSettings {
  return getItem<AppSettings>(STORAGE_KEYS.SETTINGS, DEFAULT_SETTINGS);
}

export function updateSettings(settings: Partial<AppSettings>): AppSettings {
  const current = getSettings();
  const updated = { ...current, ...settings };
  setItem(STORAGE_KEYS.SETTINGS, updated);
  return updated;
}

export function getLanguage(): Language {
  return getSettings().language;
}

export function setLanguage(lang: Language): void {
  updateSettings({ language: lang });
}

export function hasSeenOnboarding(): boolean {
  return getSettings().hasSeenOnboarding;
}

export function setOnboardingSeen(seen: boolean): void {
  updateSettings({ hasSeenOnboarding: seen });
}

// Generate unique ID
export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}
