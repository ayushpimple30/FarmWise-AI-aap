// Disease detection data and mock predictions for AgroSahayak
// This will be replaced with real AI inference when backend is connected

export interface DiseaseInfo {
  id: string;
  crop: string;
  disease: string;
  scientificName: string;
  symptoms: string[];
  treatments: {
    chemical: string[];
    organic: string[];
  };
  prevention: string[];
  images: string[];
}

export interface PredictionResult {
  crop: string;
  disease: string;
  confidence: number;
  severity: 'low' | 'medium' | 'high';
  treatments: string[];
  preventions: string[];
  diseaseInfo?: DiseaseInfo;
}

// Common crop diseases database
export const diseaseDatabase: DiseaseInfo[] = [
  {
    id: 'tomato_early_blight',
    crop: 'Tomato',
    disease: 'Early Blight',
    scientificName: 'Alternaria solani',
    symptoms: [
      'Dark brown spots with concentric rings on leaves',
      'Lower leaves affected first',
      'Yellowing around spots',
      'Fruit may have dark, sunken spots'
    ],
    treatments: {
      chemical: [
        'Apply Mancozeb 75% WP @ 2g/L water',
        'Chlorothalonil spray every 7-10 days',
        'Copper oxychloride 50% WP @ 2.5g/L'
      ],
      organic: [
        'Neem oil spray (5ml/L water)',
        'Baking soda solution (1 tsp/L water)',
        'Remove and destroy infected leaves',
        'Trichoderma viride application'
      ]
    },
    prevention: [
      'Use certified disease-free seeds',
      'Practice crop rotation (3 years)',
      'Avoid overhead irrigation',
      'Maintain proper plant spacing',
      'Mulch around plants'
    ],
    images: []
  },
  {
    id: 'tomato_late_blight',
    crop: 'Tomato',
    disease: 'Late Blight',
    scientificName: 'Phytophthora infestans',
    symptoms: [
      'Water-soaked, gray-green spots on leaves',
      'White fuzzy growth on leaf undersides',
      'Stems turn brown and collapse',
      'Fruits develop brown, firm rot'
    ],
    treatments: {
      chemical: [
        'Metalaxyl + Mancozeb @ 2.5g/L',
        'Cymoxanil + Mancozeb spray',
        'Dimethomorph 50% WP @ 1g/L'
      ],
      organic: [
        'Bordeaux mixture spray',
        'Copper-based fungicides',
        'Remove all infected plant parts immediately'
      ]
    },
    prevention: [
      'Use resistant varieties',
      'Avoid wetting foliage',
      'Ensure good air circulation',
      'Destroy crop residues after harvest',
      'Monitor weather conditions'
    ],
    images: []
  },
  {
    id: 'potato_late_blight',
    crop: 'Potato',
    disease: 'Late Blight',
    scientificName: 'Phytophthora infestans',
    symptoms: [
      'Dark, water-soaked lesions on leaves',
      'White mold on leaf undersides in humid conditions',
      'Stems may turn black',
      'Tubers show reddish-brown dry rot'
    ],
    treatments: {
      chemical: [
        'Mancozeb 75% WP @ 2.5g/L at 7-day intervals',
        'Metalaxyl-M + Mancozeb @ 2g/L',
        'Cymoxanil spray'
      ],
      organic: [
        'Bordeaux mixture (1%)',
        'Copper hydroxide spray',
        'Remove infected plants immediately'
      ]
    },
    prevention: [
      'Plant certified disease-free seed tubers',
      'Hill up soil around plants',
      'Avoid irrigation during evening',
      'Destroy all volunteer plants'
    ],
    images: []
  },
  {
    id: 'rice_blast',
    crop: 'Rice',
    disease: 'Blast Disease',
    scientificName: 'Magnaporthe oryzae',
    symptoms: [
      'Diamond-shaped spots with gray centers',
      'Brown margins on leaf spots',
      'Neck rot causing panicle breakage',
      'Node blast causing stem breakage'
    ],
    treatments: {
      chemical: [
        'Tricyclazole 75% WP @ 0.6g/L',
        'Isoprothiolane @ 1.5ml/L',
        'Carbendazim 50% WP @ 1g/L'
      ],
      organic: [
        'Pseudomonas fluorescens spray',
        'Trichoderma application',
        'Neem-based products'
      ]
    },
    prevention: [
      'Use resistant varieties (e.g., IR64, Swarna)',
      'Balanced nitrogen fertilization',
      'Maintain proper water management',
      'Remove weed hosts'
    ],
    images: []
  },
  {
    id: 'wheat_rust',
    crop: 'Wheat',
    disease: 'Rust (Yellow/Brown/Black)',
    scientificName: 'Puccinia spp.',
    symptoms: [
      'Yellow, orange, or brown pustules on leaves',
      'Pustules release powdery spores',
      'Severe yellowing and leaf death',
      'Reduced grain filling'
    ],
    treatments: {
      chemical: [
        'Propiconazole 25% EC @ 1ml/L',
        'Tebuconazole @ 1ml/L',
        'Triadimefon 25% WP @ 1g/L'
      ],
      organic: [
        'Sulfur-based sprays',
        'Early harvest if severe',
        'Remove alternate hosts'
      ]
    },
    prevention: [
      'Plant resistant varieties',
      'Early sowing to avoid peak rust period',
      'Balanced fertilization',
      'Destroy crop residues'
    ],
    images: []
  },
  {
    id: 'cotton_boll_rot',
    crop: 'Cotton',
    disease: 'Boll Rot',
    scientificName: 'Various pathogens',
    symptoms: [
      'Brown, water-soaked lesions on bolls',
      'Fuzzy fungal growth',
      'Rotting and shedding of bolls',
      'Lint staining'
    ],
    treatments: {
      chemical: [
        'Copper oxychloride @ 3g/L',
        'Carbendazim @ 1g/L',
        'Mancozeb @ 2.5g/L'
      ],
      organic: [
        'Trichoderma viride application',
        'Neem oil spray',
        'Remove infected bolls'
      ]
    },
    prevention: [
      'Avoid dense planting',
      'Proper drainage',
      'Control boll worms (entry points for rot)',
      'Timely picking of mature bolls'
    ],
    images: []
  },
  {
    id: 'maize_common_rust',
    crop: 'Maize/Corn',
    disease: 'Common Rust',
    scientificName: 'Puccinia sorghi',
    symptoms: [
      'Small, circular to elongated pustules',
      'Cinnamon-brown color pustules',
      'Occurs on both leaf surfaces',
      'Severe infections cause leaf death'
    ],
    treatments: {
      chemical: [
        'Mancozeb @ 2.5g/L',
        'Propiconazole @ 1ml/L',
        'Hexaconazole @ 1ml/L'
      ],
      organic: [
        'Sulfur dust application',
        'Remove severely infected plants',
        'Neem-based products'
      ]
    },
    prevention: [
      'Use tolerant hybrids',
      'Early planting',
      'Avoid excess nitrogen',
      'Crop rotation'
    ],
    images: []
  },
  {
    id: 'healthy',
    crop: 'Various',
    disease: 'Healthy',
    scientificName: 'N/A',
    symptoms: ['No visible disease symptoms', 'Healthy green foliage'],
    treatments: {
      chemical: [],
      organic: ['Continue regular maintenance']
    },
    prevention: [
      'Maintain balanced nutrition',
      'Regular monitoring',
      'Good agricultural practices'
    ],
    images: []
  }
];

// Simulated prediction function (to be replaced with real API call)
export async function predictDisease(imageData: string): Promise<PredictionResult> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1500 + Math.random() * 1000));
  
  // For demo purposes, randomly select a disease
  // In production, this would call the FastAPI backend
  const diseases = diseaseDatabase.filter(d => d.id !== 'healthy');
  const randomDisease = diseases[Math.floor(Math.random() * diseases.length)];
  
  // Randomly determine if healthy or diseased (20% chance healthy)
  const isHealthy = Math.random() < 0.2;
  
  if (isHealthy) {
    return {
      crop: 'Various',
      disease: 'Healthy',
      confidence: 0.85 + Math.random() * 0.14,
      severity: 'low',
      treatments: ['Continue regular crop care', 'Monitor regularly for any changes'],
      preventions: [
        'Maintain balanced nutrition',
        'Practice crop rotation',
        'Regular field inspection'
      ]
    };
  }
  
  // Generate severity based on confidence
  const confidence = 0.65 + Math.random() * 0.33;
  let severity: 'low' | 'medium' | 'high';
  
  if (confidence > 0.85) {
    severity = Math.random() > 0.5 ? 'high' : 'medium';
  } else if (confidence > 0.75) {
    severity = 'medium';
  } else {
    severity = 'low';
  }
  
  return {
    crop: randomDisease.crop,
    disease: randomDisease.disease,
    confidence,
    severity,
    treatments: [
      ...randomDisease.treatments.chemical.slice(0, 2),
      ...randomDisease.treatments.organic.slice(0, 2)
    ],
    preventions: randomDisease.prevention.slice(0, 4),
    diseaseInfo: randomDisease
  };
}

// Get disease by ID
export function getDiseaseById(id: string): DiseaseInfo | undefined {
  return diseaseDatabase.find(d => d.id === id);
}

// Get all diseases for a crop
export function getDiseasesForCrop(crop: string): DiseaseInfo[] {
  return diseaseDatabase.filter(d => 
    d.crop.toLowerCase() === crop.toLowerCase()
  );
}

// Get severity color
export function getSeverityColor(severity: 'low' | 'medium' | 'high'): string {
  switch (severity) {
    case 'low': return 'text-green-600 bg-green-100';
    case 'medium': return 'text-yellow-600 bg-yellow-100';
    case 'high': return 'text-red-600 bg-red-100';
    default: return 'text-gray-600 bg-gray-100';
  }
}

// Get severity urgency message
export function getSeverityMessage(severity: 'low' | 'medium' | 'high', lang: string = 'en'): string {
  const messages = {
    en: {
      low: 'Monitor the crop. Treatment can wait a few days.',
      medium: 'Apply treatment within 2-3 days to prevent spread.',
      high: 'Urgent! Apply treatment immediately to save the crop.'
    },
    hi: {
      low: 'फसल की निगरानी करें। उपचार कुछ दिन रुक सकता है।',
      medium: 'फैलाव रोकने के लिए 2-3 दिनों में उपचार करें।',
      high: 'तत्काल! फसल बचाने के लिए तुरंत उपचार करें।'
    },
    mr: {
      low: 'पिकावर लक्ष ठेवा. उपचार काही दिवस थांबू शकतो.',
      medium: 'प्रसार रोखण्यासाठी 2-3 दिवसांत उपचार करा.',
      high: 'तातडीने! पीक वाचवण्यासाठी लगेच उपचार करा.'
    }
  };
  
  return messages[lang as keyof typeof messages]?.[severity] || messages.en[severity];
}
