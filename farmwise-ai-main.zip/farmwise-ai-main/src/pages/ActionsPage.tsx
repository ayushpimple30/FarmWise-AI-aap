import { useEffect, useState } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext';
import { ArrowLeft, AlertCircle, Shield, Beaker, Leaf } from 'lucide-react';
import ListenButton from '@/components/ListenButton';
import { ScanResult, getScanResultById } from '@/lib/storage';
import { getDiseaseById, DiseaseInfo } from '@/lib/diseaseData';

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 }
};

export default function ActionsPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  const { t, language } = useLanguage();
  
  const [result, setResult] = useState<ScanResult | null>(null);
  const [diseaseInfo, setDiseaseInfo] = useState<DiseaseInfo | null>(null);
  
  useEffect(() => {
    if (location.state?.result) {
      const stateResult = location.state.result;
      setResult(stateResult);
      
      // Try to get additional disease info
      if (stateResult.diseaseInfo) {
        setDiseaseInfo(stateResult.diseaseInfo);
      }
    } else if (id) {
      const storedResult = getScanResultById(id);
      if (storedResult) {
        setResult(storedResult);
      } else {
        navigate('/history');
      }
    }
  }, [id, location.state, navigate]);
  
  if (!result) {
    return (
      <div className="page-container flex items-center justify-center">
        <div className="animate-pulse text-muted-foreground">{t('loading')}</div>
      </div>
    );
  }
  
  const sections = [
    {
      title: t('immediateActions'),
      icon: AlertCircle,
      color: 'from-red-500 to-rose-600',
      bgColor: 'bg-red-50',
      textColor: 'text-red-700',
      items: result.severity === 'high' 
        ? ['Remove and destroy infected leaves immediately', 'Isolate affected plants if possible', 'Avoid overhead watering']
        : ['Continue monitoring the affected area', 'Take photos to track progress']
    },
    {
      title: t('chemicalTreatment'),
      icon: Beaker,
      color: 'from-blue-500 to-indigo-600',
      bgColor: 'bg-blue-50',
      textColor: 'text-blue-700',
      items: diseaseInfo?.treatments.chemical || result.treatments.slice(0, 3)
    },
    {
      title: t('organicTreatment'),
      icon: Leaf,
      color: 'from-green-500 to-emerald-600',
      bgColor: 'bg-green-50',
      textColor: 'text-green-700',
      items: diseaseInfo?.treatments.organic || ['Neem oil spray', 'Remove infected parts', 'Improve air circulation']
    },
    {
      title: t('preventiveMeasures'),
      icon: Shield,
      color: 'from-amber-500 to-orange-600',
      bgColor: 'bg-amber-50',
      textColor: 'text-amber-700',
      items: result.preventions
    }
  ];
  
  // Text for TTS
  const actionsText = sections.map(section => 
    `${section.title}: ${section.items.join('. ')}`
  ).join('. ');
  
  return (
    <div className="page-container px-4">
      {/* Header */}
      <motion.header
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6 flex items-center justify-between"
      >
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate(-1)}
            className="rounded-xl p-2 hover:bg-muted"
          >
            <ArrowLeft className="h-6 w-6" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-foreground">{t('actionsTitle')}</h1>
            <p className="text-sm text-muted-foreground">
              {result.crop} - {result.disease}
            </p>
          </div>
        </div>
        
        <ListenButton text={actionsText} size="sm" />
      </motion.header>
      
      {/* Action Sections */}
      <motion.div
        variants={container}
        initial="hidden"
        animate="show"
        className="space-y-4"
      >
        {sections.map((section) => {
          const Icon = section.icon;
          return (
            <motion.div
              key={section.title}
              variants={item}
              className="rounded-3xl bg-card p-5 shadow-soft"
            >
              {/* Section Header */}
              <div className="mb-4 flex items-center gap-3">
                <div className={`rounded-xl bg-gradient-to-br ${section.color} p-2.5`}>
                  <Icon className="h-5 w-5 text-white" />
                </div>
                <h2 className="text-lg font-bold text-foreground">{section.title}</h2>
              </div>
              
              {/* Items */}
              <div className="space-y-2">
                {section.items.map((actionItem, index) => (
                  <div
                    key={index}
                    className={`rounded-xl ${section.bgColor} p-3`}
                  >
                    <div className="flex items-start gap-3">
                      <div className={`mt-1 h-2 w-2 flex-shrink-0 rounded-full ${section.textColor.replace('text-', 'bg-')}`} />
                      <p className={`text-sm font-medium ${section.textColor}`}>{actionItem}</p>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          );
        })}
      </motion.div>
      
      {/* Back to Results */}
      <motion.button
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        whileTap={{ scale: 0.98 }}
        onClick={() => navigate(-1)}
        className="mt-6 flex w-full items-center justify-center gap-3 rounded-2xl border-2 border-muted-foreground/30 bg-card px-6 py-4 font-bold text-muted-foreground transition-colors hover:bg-muted"
      >
        <ArrowLeft className="h-5 w-5" />
        <span>Back to Results</span>
      </motion.button>
    </div>
  );
}
