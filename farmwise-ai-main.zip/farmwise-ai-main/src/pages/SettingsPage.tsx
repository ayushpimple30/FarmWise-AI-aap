import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';
import { useOnboarding } from '@/contexts/OnboardingContext';
import { ArrowLeft, Globe, HelpCircle, Info, Download } from 'lucide-react';
import LanguageSwitcher from '@/components/LanguageSwitcher';

export default function SettingsPage() {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const { startOnboarding } = useOnboarding();
  
  return (
    <div className="page-container px-4">
      <motion.header initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="mb-6 flex items-center gap-4">
        <button onClick={() => navigate(-1)} className="rounded-xl p-2 hover:bg-muted"><ArrowLeft className="h-6 w-6" /></button>
        <h1 className="text-2xl font-bold text-foreground">{t('settingsTitle')}</h1>
      </motion.header>
      
      <div className="space-y-4">
        {/* Language */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="rounded-3xl bg-card p-5 shadow-soft">
          <div className="mb-4 flex items-center gap-3"><Globe className="h-5 w-5 text-primary" /><h2 className="font-bold">{t('language')}</h2></div>
          <LanguageSwitcher />
        </motion.div>
        
        {/* Replay Guide */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="rounded-3xl bg-card p-5 shadow-soft">
          <button onClick={() => { startOnboarding(); navigate('/'); }} className="flex w-full items-center gap-3 text-left">
            <HelpCircle className="h-5 w-5 text-primary" />
            <span className="font-bold">{t('replayGuide')}</span>
          </button>
        </motion.div>
        
        {/* Install App */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="rounded-3xl bg-card p-5 shadow-soft">
          <div className="flex items-center gap-3"><Download className="h-5 w-5 text-primary" /><span className="font-bold">{t('installApp')}</span></div>
          <p className="mt-2 text-sm text-muted-foreground">{t('installPromptDesc')}</p>
        </motion.div>
        
        {/* About */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="rounded-3xl bg-card p-5 shadow-soft">
          <div className="flex items-center gap-3"><Info className="h-5 w-5 text-primary" /><span className="font-bold">{t('about')}</span></div>
          <p className="mt-2 text-sm text-muted-foreground">{t('appName')} - {t('tagline')}</p>
          <p className="mt-1 text-xs text-muted-foreground">{t('version')} 1.0.0</p>
        </motion.div>
      </div>
    </div>
  );
}
