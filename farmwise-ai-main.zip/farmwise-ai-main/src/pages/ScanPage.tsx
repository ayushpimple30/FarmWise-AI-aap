import { useState, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext';
import { Camera, Upload, X, AlertTriangle, CheckCircle, Loader2, Scan } from 'lucide-react';
import { predictDisease, PredictionResult } from '@/lib/diseaseData';
import { addScanResult } from '@/lib/storage';

type ImageQuality = 'good' | 'dark' | 'blurry' | 'far' | null;

export default function ScanPage() {
  const navigate = useNavigate();
  const { t } = useLanguage();
  
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [imageQuality, setImageQuality] = useState<ImageQuality>(null);
  const [isCameraActive, setIsCameraActive] = useState(false);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  
  // Start camera
  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: 1280, height: 720 }
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        streamRef.current = stream;
        setIsCameraActive(true);
      }
    } catch (error) {
      console.error('Camera access error:', error);
      alert('Unable to access camera. Please check permissions.');
    }
  };
  
  // Stop camera
  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setIsCameraActive(false);
  };
  
  // Capture photo
  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      
      const ctx = canvas.getContext('2d');
      ctx?.drawImage(video, 0, 0);
      
      const imageData = canvas.toDataURL('image/jpeg', 0.8);
      setCapturedImage(imageData);
      checkImageQuality(canvas);
      stopCamera();
    }
  };
  
  // Check image quality (simplified)
  const checkImageQuality = (canvas: HTMLCanvasElement) => {
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imageData.data;
    
    // Calculate average brightness
    let totalBrightness = 0;
    for (let i = 0; i < data.length; i += 4) {
      const brightness = (data[i] + data[i + 1] + data[i + 2]) / 3;
      totalBrightness += brightness;
    }
    const avgBrightness = totalBrightness / (data.length / 4);
    
    // Simple quality check
    if (avgBrightness < 50) {
      setImageQuality('dark');
    } else {
      setImageQuality('good');
    }
  };
  
  // Handle file upload
  const handleFileUpload = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        setCapturedImage(result);
        setImageQuality('good'); // Assume uploaded images are good
      };
      reader.readAsDataURL(file);
    }
  }, []);
  
  // Analyze image
  const analyzeImage = async () => {
    if (!capturedImage) return;
    
    setIsAnalyzing(true);
    
    try {
      const result: PredictionResult = await predictDisease(capturedImage);
      
      // Save to history
      const savedResult = addScanResult({
        imageData: capturedImage,
        crop: result.crop,
        disease: result.disease,
        confidence: result.confidence,
        severity: result.severity,
        treatments: result.treatments,
        preventions: result.preventions
      });
      
      // Navigate to results
      navigate(`/result/${savedResult.id}`, { 
        state: { result, imageData: capturedImage, isNew: true } 
      });
    } catch (error) {
      console.error('Analysis error:', error);
      alert('Analysis failed. Please try again.');
    } finally {
      setIsAnalyzing(false);
    }
  };
  
  // Reset
  const resetCapture = () => {
    setCapturedImage(null);
    setImageQuality(null);
    stopCamera();
  };
  
  return (
    <div className="page-container px-4">
      {/* Header */}
      <motion.header
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6"
      >
        <h1 className="text-2xl font-bold text-foreground">{t('scanTitle')}</h1>
        <p className="mt-1 text-muted-foreground">{t('scanInstruction')}</p>
      </motion.header>
      
      {/* Camera / Preview Area */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="relative aspect-[4/3] overflow-hidden rounded-3xl bg-black/10"
      >
        {/* Camera View */}
        {isCameraActive && !capturedImage && (
          <video
            ref={videoRef}
            autoPlay
            playsInline
            className="h-full w-full object-cover"
          />
        )}
        
        {/* Captured Image */}
        {capturedImage && (
          <img
            src={capturedImage}
            alt="Captured"
            className="h-full w-full object-cover"
          />
        )}
        
        {/* Placeholder */}
        {!isCameraActive && !capturedImage && (
          <div className="flex h-full w-full flex-col items-center justify-center">
            <Camera className="h-16 w-16 text-muted-foreground/50" />
            <p className="mt-4 text-muted-foreground">{t('scanInstruction')}</p>
          </div>
        )}
        
        {/* Scan frame overlay */}
        {(isCameraActive || capturedImage) && (
          <div className="absolute inset-4 rounded-2xl border-2 border-white/50 pointer-events-none">
            <div className="absolute -left-1 -top-1 h-6 w-6 border-l-4 border-t-4 border-primary rounded-tl-lg" />
            <div className="absolute -right-1 -top-1 h-6 w-6 border-r-4 border-t-4 border-primary rounded-tr-lg" />
            <div className="absolute -bottom-1 -left-1 h-6 w-6 border-b-4 border-l-4 border-primary rounded-bl-lg" />
            <div className="absolute -bottom-1 -right-1 h-6 w-6 border-b-4 border-r-4 border-primary rounded-br-lg" />
          </div>
        )}
        
        {/* Close button */}
        {(isCameraActive || capturedImage) && (
          <button
            onClick={resetCapture}
            className="absolute right-3 top-3 rounded-full bg-black/50 p-2 text-white"
          >
            <X className="h-5 w-5" />
          </button>
        )}
        
        {/* Capture button */}
        {isCameraActive && !capturedImage && (
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={capturePhoto}
            className="absolute bottom-4 left-1/2 -translate-x-1/2 flex h-16 w-16 items-center justify-center rounded-full bg-white shadow-lg"
          >
            <div className="h-12 w-12 rounded-full border-4 border-primary" />
          </motion.button>
        )}
        
        <canvas ref={canvasRef} className="hidden" />
      </motion.div>
      
      {/* Image Quality Warning */}
      <AnimatePresence>
        {imageQuality && imageQuality !== 'good' && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="mt-4 flex items-center gap-3 rounded-xl bg-yellow-50 p-4 text-yellow-800"
          >
            <AlertTriangle className="h-5 w-5 flex-shrink-0" />
            <p className="text-sm font-medium">
              {imageQuality === 'dark' && t('tooDark')}
              {imageQuality === 'blurry' && t('tooBlurry')}
              {imageQuality === 'far' && t('tooFar')}
            </p>
          </motion.div>
        )}
        
        {imageQuality === 'good' && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="mt-4 flex items-center gap-3 rounded-xl bg-green-50 p-4 text-green-800"
          >
            <CheckCircle className="h-5 w-5 flex-shrink-0" />
            <p className="text-sm font-medium">{t('goodQuality')}</p>
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Action Buttons */}
      <div className="mt-6 space-y-3">
        {!capturedImage ? (
          <>
            <motion.button
              whileTap={{ scale: 0.98 }}
              onClick={isCameraActive ? capturePhoto : startCamera}
              className="btn-primary flex w-full items-center justify-center gap-3"
            >
              <Camera className="h-6 w-6" />
              <span>{t('takePhoto')}</span>
            </motion.button>
            
            <motion.button
              whileTap={{ scale: 0.98 }}
              onClick={() => fileInputRef.current?.click()}
              className="flex w-full items-center justify-center gap-3 rounded-2xl border-2 border-primary bg-card px-6 py-4 font-bold text-primary transition-colors hover:bg-primary/5"
            >
              <Upload className="h-6 w-6" />
              <span>{t('uploadPhoto')}</span>
            </motion.button>
            
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              onChange={handleFileUpload}
              className="hidden"
            />
          </>
        ) : (
          <>
            <motion.button
              whileTap={{ scale: 0.98 }}
              onClick={analyzeImage}
              disabled={isAnalyzing}
              className="btn-primary flex w-full items-center justify-center gap-3"
            >
              {isAnalyzing ? (
                <>
                  <Loader2 className="h-6 w-6 animate-spin" />
                  <span>{t('analyzing')}</span>
                </>
              ) : (
                <>
                  <Scan className="h-6 w-6" />
                  <span>Analyze</span>
                </>
              )}
            </motion.button>
            
            <motion.button
              whileTap={{ scale: 0.98 }}
              onClick={resetCapture}
              className="flex w-full items-center justify-center gap-3 rounded-2xl border-2 border-muted-foreground/30 bg-card px-6 py-4 font-bold text-muted-foreground transition-colors hover:bg-muted"
            >
              <span>{t('scanAgain')}</span>
            </motion.button>
          </>
        )}
      </div>
      
      {/* Tip */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="mt-6 rounded-2xl bg-muted p-4"
      >
        <p className="text-center text-sm text-muted-foreground">{t('scanTip')}</p>
      </motion.div>
    </div>
  );
}
