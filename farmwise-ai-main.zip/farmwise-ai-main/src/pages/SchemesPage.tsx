import { motion } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext';
import { Building2, Phone, ExternalLink, Shield, Leaf, Microscope } from 'lucide-react';

export default function SchemesPage() {
  const { t } = useLanguage();
  
  const schemes = [
    { icon: Building2, title: t('pmKisan'), description: t('pmKisanDesc'), color: 'from-green-500 to-emerald-600', link: 'https://pmkisan.gov.in' },
    { icon: Shield, title: t('cropInsurance'), description: t('cropInsuranceDesc'), color: 'from-blue-500 to-indigo-600', link: 'https://pmfby.gov.in' },
    { icon: Microscope, title: t('soilHealth'), description: t('soilHealthDesc'), color: 'from-amber-500 to-orange-600', link: 'https://soilhealth.dac.gov.in' },
    { icon: Phone, title: t('kisanCallCenter'), description: t('kisanCallCenterDesc'), color: 'from-purple-500 to-violet-600', phone: '1800-180-1551' },
  ];
  
  return (
    <div className="page-container px-4">
      <motion.header initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="mb-6">
        <h1 className="text-2xl font-bold text-foreground">{t('schemesTitle')}</h1>
      </motion.header>
      
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
        {schemes.map((scheme, i) => {
          const Icon = scheme.icon;
          return (
            <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }} className="scheme-card">
              <div className="flex items-start gap-4">
                <div className={`rounded-xl bg-gradient-to-br ${scheme.color} p-3`}>
                  <Icon className="h-6 w-6 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-foreground">{scheme.title}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{scheme.description}</p>
                  <div className="mt-3">
                    {scheme.phone ? (
                      <a href={`tel:${scheme.phone}`} className="inline-flex items-center gap-2 rounded-xl bg-primary/10 px-4 py-2 font-semibold text-primary">
                        <Phone className="h-4 w-4" />{t('callNow')}
                      </a>
                    ) : (
                      <a href={scheme.link} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 rounded-xl bg-primary/10 px-4 py-2 font-semibold text-primary">
                        <ExternalLink className="h-4 w-4" />{t('learnMore')}
                      </a>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          );
        })}
      </motion.div>
    </div>
  );
}
