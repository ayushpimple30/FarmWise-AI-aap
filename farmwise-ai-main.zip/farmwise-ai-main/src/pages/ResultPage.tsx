import { useEffect, useState } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext';
import { ArrowLeft, ChevronRight, AlertTriangle, CheckCircle } from 'lucide-react';
import ListenButton from '@/components/ListenButton';
import SeverityBadge from '@/components/SeverityBadge';
import { ScanResult, getScanResultById } from '@/lib/storage';
import { getSeverityMessage } from '@/lib/diseaseData';

export default function ResultPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  const { t, language } = useLanguage();
  
  const [result, setResult] = useState<ScanResult | null>(null);
  
  useEffect(() => {
    // Try to get from location state first (for new scans)
    if (location.state?.result) {
      const stateResult = location.state.result;
      setResult({
        id: id || '',
        imageData: location.state.imageData || '',
        crop: stateResult.crop,
        disease: stateResult.disease,
        confidence: stateResult.confidence,
        severity: stateResult.severity,
        timestamp: Date.now(),
        treatments: stateResult.treatments,
        preventions: stateResult.preventions
      });
    } else if (id) {
      // Load from storage
      const storedResult = getScanResultById(id);
      if (storedResult) {
        setResult(storedResult);
      } else {
        navigate('/history');
      }
    }
  }, [id, location.state, navigate]);
  
  if (!result) {
    return (
      <div className="page-container flex items-center justify-center">
        <div className="animate-pulse text-muted-foreground">{t('loading')}</div>
      </div>
    );
  }
  
  const isHealthy = result.disease.toLowerCase() === 'healthy';
  const severityMessage = getSeverityMessage(result.severity, language);
  
  // Text for TTS
  const resultText = `
    ${t('crop')}: ${result.crop}. 
    ${t('disease')}: ${result.disease}. 
    ${t('confidence')}: ${Math.round(result.confidence * 100)}%. 
    ${t('severity')}: ${result.severity}. 
    ${severityMessage}
  `;
  
  return (
    <div className="page-container px-4">
      {/* Header */}
      <motion.header
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6 flex items-center gap-4"
      >
        <button
          onClick={() => navigate(-1)}
          className="rounded-xl p-2 hover:bg-muted"
        >
          <ArrowLeft className="h-6 w-6" />
        </button>
        <h1 className="text-2xl font-bold text-foreground">{t('resultTitle')}</h1>
      </motion.header>
      
      {/* Result Card */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="rounded-3xl bg-card p-5 shadow-card"
      >
        {/* Image */}
        <div className="relative aspect-[4/3] overflow-hidden rounded-2xl bg-muted">
          {result.imageData && (
            <img
              src={result.imageData}
              alt="Scanned crop"
              className="h-full w-full object-cover"
            />
          )}
          
          {/* Status overlay */}
          <div className="absolute bottom-3 left-3">
            <SeverityBadge severity={result.severity} size="lg" />
          </div>
        </div>
        
        {/* Details */}
        <div className="mt-5 space-y-4">
          {/* Crop & Disease */}
          <div className="grid grid-cols-2 gap-4">
            <div className="rounded-2xl bg-muted p-4">
              <p className="text-sm text-muted-foreground">{t('crop')}</p>
              <p className="mt-1 text-lg font-bold text-foreground">{result.crop}</p>
            </div>
            <div className="rounded-2xl bg-muted p-4">
              <p className="text-sm text-muted-foreground">{t('disease')}</p>
              <p className={`mt-1 text-lg font-bold ${isHealthy ? 'text-green-600' : 'text-red-600'}`}>
                {result.disease}
              </p>
            </div>
          </div>
          
          {/* Confidence */}
          <div className="rounded-2xl bg-muted p-4">
            <div className="flex items-center justify-between">
              <p className="text-sm text-muted-foreground">{t('confidence')}</p>
              <p className="font-bold text-foreground">{Math.round(result.confidence * 100)}%</p>
            </div>
            <div className="confidence-bar mt-2">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${result.confidence * 100}%` }}
                transition={{ duration: 1, ease: 'easeOut' }}
                className="confidence-fill"
              />
            </div>
          </div>
          
          {/* Severity Message */}
          <div className={`flex items-start gap-3 rounded-2xl p-4 ${
            result.severity === 'high' ? 'bg-red-50 text-red-800' :
            result.severity === 'medium' ? 'bg-yellow-50 text-yellow-800' :
            'bg-green-50 text-green-800'
          }`}>
            {result.severity === 'high' || result.severity === 'medium' ? (
              <AlertTriangle className="h-5 w-5 flex-shrink-0 mt-0.5" />
            ) : (
              <CheckCircle className="h-5 w-5 flex-shrink-0 mt-0.5" />
            )}
            <p className="font-medium">{severityMessage}</p>
          </div>
        </div>
        
        {/* Listen Button */}
        <div className="mt-5 flex justify-center">
          <ListenButton text={resultText} size="lg" />
        </div>
      </motion.div>
      
      {/* Actions */}
      {!isHealthy && (
        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => navigate(`/actions/${id}`, { state: { result } })}
          className="btn-action mt-6 flex w-full items-center justify-center gap-3"
        >
          <span>{t('viewActions')}</span>
          <ChevronRight className="h-5 w-5" />
        </motion.button>
      )}
      
      {/* Scan Again */}
      <motion.button
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        whileTap={{ scale: 0.98 }}
        onClick={() => navigate('/scan')}
        className="mt-3 flex w-full items-center justify-center gap-3 rounded-2xl border-2 border-muted-foreground/30 bg-card px-6 py-4 font-bold text-muted-foreground transition-colors hover:bg-muted"
      >
        <span>{t('scanAgain')}</span>
      </motion.button>
    </div>
  );
}
