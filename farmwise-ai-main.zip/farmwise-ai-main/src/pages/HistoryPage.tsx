import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext';
import { Clock, Trash2, ChevronRight, Leaf } from 'lucide-react';
import { getScanHistory, deleteScanResult, ScanResult } from '@/lib/storage';
import SeverityBadge from '@/components/SeverityBadge';

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.05 }
  }
};

const item = {
  hidden: { opacity: 0, x: -20 },
  show: { opacity: 1, x: 0 }
};

export default function HistoryPage() {
  const navigate = useNavigate();
  const { t } = useLanguage();
  
  const [history, setHistory] = useState<ScanResult[]>(() => getScanHistory());
  const [deletingId, setDeletingId] = useState<string | null>(null);
  
  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setDeletingId(id);
    
    setTimeout(() => {
      deleteScanResult(id);
      setHistory(getScanHistory());
      setDeletingId(null);
    }, 300);
  };
  
  const formatDate = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleDateString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };
  
  return (
    <div className="page-container px-4">
      {/* Header */}
      <motion.header
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6"
      >
        <h1 className="text-2xl font-bold text-foreground">{t('historyTitle')}</h1>
      </motion.header>
      
      {/* History List */}
      {history.length > 0 ? (
        <motion.div
          variants={container}
          initial="hidden"
          animate="show"
          className="space-y-3"
        >
          <AnimatePresence>
            {history.map((scan) => (
              <motion.div
                key={scan.id}
                variants={item}
                exit={{ opacity: 0, x: -100, height: 0 }}
                layout
                className={`${deletingId === scan.id ? 'opacity-50' : ''}`}
              >
                <motion.button
                  whileTap={{ scale: 0.98 }}
                  onClick={() => navigate(`/result/${scan.id}`)}
                  className="w-full rounded-2xl bg-card p-4 shadow-soft text-left"
                >
                  <div className="flex gap-4">
                    {/* Thumbnail */}
                    <div className="relative h-20 w-20 flex-shrink-0 overflow-hidden rounded-xl bg-muted">
                      {scan.imageData ? (
                        <img
                          src={scan.imageData}
                          alt={scan.crop}
                          className="h-full w-full object-cover"
                        />
                      ) : (
                        <div className="flex h-full w-full items-center justify-center">
                          <Leaf className="h-8 w-8 text-muted-foreground/50" />
                        </div>
                      )}
                    </div>
                    
                    {/* Details */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h3 className="font-bold text-foreground">{scan.crop}</h3>
                          <p className={`text-sm font-medium ${
                            scan.disease === 'Healthy' ? 'text-green-600' : 'text-red-600'
                          }`}>
                            {scan.disease}
                          </p>
                        </div>
                        <SeverityBadge severity={scan.severity} showIcon={false} size="sm" />
                      </div>
                      
                      <div className="mt-2 flex items-center gap-1 text-xs text-muted-foreground">
                        <Clock className="h-3 w-3" />
                        <span>{formatDate(scan.timestamp)}</span>
                      </div>
                    </div>
                    
                    {/* Actions */}
                    <div className="flex flex-col items-center justify-between">
                      <button
                        onClick={(e) => handleDelete(scan.id, e)}
                        className="rounded-lg p-2 text-red-500 hover:bg-red-50"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                      <ChevronRight className="h-5 w-5 text-muted-foreground" />
                    </div>
                  </div>
                </motion.button>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
      ) : (
        /* Empty State */
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="flex flex-col items-center justify-center rounded-3xl bg-card p-10 text-center shadow-soft"
        >
          <div className="mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-muted">
            <Clock className="h-10 w-10 text-muted-foreground" />
          </div>
          <h2 className="text-xl font-bold text-foreground">{t('noHistory')}</h2>
          <p className="mt-2 text-muted-foreground">{t('noHistoryDesc')}</p>
          
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => navigate('/scan')}
            className="btn-primary mt-6"
          >
            {t('scanCrop')}
          </motion.button>
        </motion.div>
      )}
    </div>
  );
}
