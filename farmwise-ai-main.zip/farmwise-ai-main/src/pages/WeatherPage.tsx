import { motion } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext';
import { useWeather, getFarmingAdvice } from '@/hooks/useWeather';
import { Cloud, Droplets, Wind, Thermometer, RefreshCw, WifiOff, Droplet, AlertTriangle, Leaf } from 'lucide-react';
import ListenButton from '@/components/ListenButton';

export default function WeatherPage() {
  const { t } = useLanguage();
  const { weather, isLoading, isOffline, refetch } = useWeather();
  
  const advice = weather ? getFarmingAdvice(weather) : null;
  
  const weatherText = weather ? `
    ${t('currentWeather')}: ${weather.current.temp} degrees, ${weather.current.description}.
    ${t('humidity')}: ${weather.current.humidity}%.
    ${advice?.general || ''}
    ${advice?.irrigation || ''}
  ` : '';
  
  if (isLoading) {
    return (
      <div className="page-container flex items-center justify-center">
        <RefreshCw className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  return (
    <div className="page-container px-4">
      <motion.header initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-bold text-foreground">{t('weatherTitle')}</h1>
        <div className="flex items-center gap-2">
          {isOffline && <WifiOff className="h-5 w-5 text-warning" />}
          <button onClick={refetch} className="rounded-xl p-2 hover:bg-muted">
            <RefreshCw className="h-5 w-5" />
          </button>
        </div>
      </motion.header>
      
      {weather && (
        <>
          {/* Current Weather */}
          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="weather-card mb-6">
            <p className="text-sm opacity-80">{weather.location}</p>
            <div className="mt-4 flex items-center justify-between">
              <div>
                <p className="text-5xl font-bold">{weather.current.temp}°C</p>
                <p className="mt-1 text-lg">{weather.current.description}</p>
              </div>
              <Cloud className="h-16 w-16 opacity-80" />
            </div>
            <div className="mt-4 grid grid-cols-3 gap-4">
              <div className="flex items-center gap-2"><Droplets className="h-5 w-5" /><span>{weather.current.humidity}%</span></div>
              <div className="flex items-center gap-2"><Wind className="h-5 w-5" /><span>{weather.current.windSpeed} km/h</span></div>
              <div className="flex items-center gap-2"><Droplet className="h-5 w-5" /><span>{weather.current.rainProbability}%</span></div>
            </div>
          </motion.div>
          
          {/* Farming Advice */}
          {advice && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-6 rounded-3xl bg-card p-5 shadow-soft">
              <div className="mb-4 flex items-center justify-between">
                <h2 className="text-lg font-bold">{t('farmingAdvice')}</h2>
                <ListenButton text={weatherText} size="sm" />
              </div>
              <div className="space-y-3">
                <div className="rounded-xl bg-blue-50 p-3"><div className="flex items-center gap-2 text-blue-700"><Droplets className="h-4 w-4" /><span className="text-sm font-medium">{advice.irrigation}</span></div></div>
                <div className="rounded-xl bg-amber-50 p-3"><div className="flex items-center gap-2 text-amber-700"><AlertTriangle className="h-4 w-4" /><span className="text-sm font-medium">{advice.spray}</span></div></div>
                <div className="rounded-xl bg-green-50 p-3"><div className="flex items-center gap-2 text-green-700"><Leaf className="h-4 w-4" /><span className="text-sm font-medium">{advice.diseaseRisk}</span></div></div>
              </div>
            </motion.div>
          )}
          
          {/* 5-Day Forecast */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="rounded-3xl bg-card p-5 shadow-soft">
            <h2 className="mb-4 text-lg font-bold">{t('forecast')}</h2>
            <div className="space-y-3">
              {weather.forecast.map((day, i) => (
                <div key={i} className="flex items-center justify-between rounded-xl bg-muted p-3">
                  <span className="font-medium">{new Date(day.date).toLocaleDateString(undefined, { weekday: 'short' })}</span>
                  <div className="flex items-center gap-2"><Thermometer className="h-4 w-4 text-muted-foreground" /><span>{day.minTemp}° - {day.maxTemp}°</span></div>
                  <span className="text-sm text-muted-foreground">{day.description}</span>
                </div>
              ))}
            </div>
          </motion.div>
        </>
      )}
    </div>
  );
}
