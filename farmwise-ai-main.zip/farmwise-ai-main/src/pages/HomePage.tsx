import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';
import { Scan, Clock, Cloud, Building2, Leaf, Settings } from 'lucide-react';

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 }
};

export default function HomePage() {
  const navigate = useNavigate();
  const { t } = useLanguage();
  
  const features = [
    {
      icon: Scan,
      title: t('scanCrop'),
      description: t('scanDescription'),
      path: '/scan',
      color: 'from-green-500 to-emerald-600',
      onboardingId: 'scan-card'
    },
    {
      icon: Clock,
      title: t('viewHistory'),
      description: t('historyDescription'),
      path: '/history',
      color: 'from-blue-500 to-cyan-600',
      onboardingId: 'history-card'
    },
    {
      icon: Cloud,
      title: t('checkWeather'),
      description: t('weatherDescription'),
      path: '/weather',
      color: 'from-sky-500 to-blue-600',
      onboardingId: 'weather-card'
    },
    {
      icon: Building2,
      title: t('govSchemes'),
      description: t('schemesDescription'),
      path: '/schemes',
      color: 'from-amber-500 to-orange-600',
      onboardingId: 'schemes-card'
    },
  ];
  
  return (
    <div className="page-container px-4">
      {/* Header */}
      <motion.header
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6 flex items-center justify-between"
      >
        <div className="flex items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary shadow-glow">
            <Leaf className="h-7 w-7 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-foreground">{t('appName')}</h1>
            <p className="text-sm text-muted-foreground">{t('tagline')}</p>
          </div>
        </div>
        
        <motion.button
          whileTap={{ scale: 0.95 }}
          onClick={() => navigate('/settings')}
          className="rounded-xl p-2.5 hover:bg-muted"
        >
          <Settings className="h-6 w-6 text-muted-foreground" />
        </motion.button>
      </motion.header>
      
      {/* Welcome Message */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="mb-6 rounded-3xl bg-gradient-to-br from-primary to-green-600 p-6 text-white shadow-lg"
      >
        <h2 className="text-2xl font-bold">{t('welcomeMessage')}</h2>
        <p className="mt-2 opacity-90">{t('tagline')}</p>
        
        {/* Quick scan button */}
        <motion.button
          whileTap={{ scale: 0.95 }}
          onClick={() => navigate('/scan')}
          className="mt-4 flex items-center gap-2 rounded-2xl bg-white/20 px-5 py-3 font-semibold backdrop-blur-sm transition-colors hover:bg-white/30"
        >
          <Scan className="h-5 w-5" />
          <span>{t('scanCrop')}</span>
        </motion.button>
      </motion.div>
      
      {/* Feature Grid */}
      <motion.div
        variants={container}
        initial="hidden"
        animate="show"
        className="grid grid-cols-2 gap-4"
      >
        {features.map((feature) => {
          const Icon = feature.icon;
          return (
            <motion.div
              key={feature.path}
              variants={item}
              data-onboarding={feature.onboardingId}
            >
              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={() => navigate(feature.path)}
                className="feature-card w-full text-left"
              >
                <div className={`mb-3 inline-flex rounded-xl bg-gradient-to-br ${feature.color} p-3`}>
                  <Icon className="h-6 w-6 text-white" />
                </div>
                <h3 className="font-bold text-foreground">{feature.title}</h3>
                <p className="mt-1 text-sm text-muted-foreground line-clamp-2">
                  {feature.description}
                </p>
              </motion.button>
            </motion.div>
          );
        })}
      </motion.div>
      
      {/* Tips Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-6 rounded-2xl border border-primary/20 bg-primary/5 p-4"
      >
        <h3 className="flex items-center gap-2 font-semibold text-primary">
          <Leaf className="h-5 w-5" />
          {t('scanTip')}
        </h3>
      </motion.div>
    </div>
  );
}
