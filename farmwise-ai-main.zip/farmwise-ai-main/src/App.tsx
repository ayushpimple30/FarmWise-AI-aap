import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { LanguageProvider } from "@/contexts/LanguageContext";
import { OnboardingProvider } from "@/contexts/OnboardingContext";

import BottomNavigation from "@/components/BottomNavigation";
import WelcomeDialog from "@/components/WelcomeDialog";
import OnboardingOverlay from "@/components/OnboardingOverlay";
import PWAInstallPrompt from "@/components/PWAInstallPrompt";

import HomePage from "@/pages/HomePage";
import ScanPage from "@/pages/ScanPage";
import ResultPage from "@/pages/ResultPage";
import ActionsPage from "@/pages/ActionsPage";
import HistoryPage from "@/pages/HistoryPage";
import WeatherPage from "@/pages/WeatherPage";
import SchemesPage from "@/pages/SchemesPage";
import SettingsPage from "@/pages/SettingsPage";
import NotFound from "@/pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <LanguageProvider>
      <OnboardingProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <div className="relative min-h-screen">
              <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/scan" element={<ScanPage />} />
                <Route path="/result/:id" element={<ResultPage />} />
                <Route path="/actions/:id" element={<ActionsPage />} />
                <Route path="/history" element={<HistoryPage />} />
                <Route path="/weather" element={<WeatherPage />} />
                <Route path="/schemes" element={<SchemesPage />} />
                <Route path="/settings" element={<SettingsPage />} />
                <Route path="*" element={<NotFound />} />
              </Routes>
              <BottomNavigation />
              <WelcomeDialog />
              <OnboardingOverlay />
              <PWAInstallPrompt />
            </div>
          </BrowserRouter>
        </TooltipProvider>
      </OnboardingProvider>
    </LanguageProvider>
  </QueryClientProvider>
);

export default App;
