import { motion, AnimatePresence } from 'framer-motion';
import { useOnboarding } from '@/contexts/OnboardingContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { X, ChevronRight, ChevronLeft } from 'lucide-react';
import { useTTS } from '@/hooks/useTTS';
import { useEffect } from 'react';

export default function OnboardingOverlay() {
  const { 
    isOnboardingActive, 
    currentStep, 
    steps,
    nextStep, 
    prevStep,
    skipOnboarding,
    finishOnboarding
  } = useOnboarding();
  const { t } = useLanguage();
  const { speakText, stopSpeaking } = useTTS();
  
  const step = steps[currentStep];
  const isLastStep = currentStep === steps.length - 1;
  
  // Speak the current step description
  useEffect(() => {
    if (isOnboardingActive && step) {
      const text = t(step.title as any);
      speakText(text);
    }
    
    return () => {
      stopSpeaking();
    };
  }, [currentStep, isOnboardingActive]);
  
  if (!isOnboardingActive) return null;
  
  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="onboarding-overlay"
      >
        {/* Skip button */}
        <button
          onClick={skipOnboarding}
          className="absolute top-4 right-4 flex items-center gap-2 rounded-xl bg-white/20 px-4 py-2 text-white backdrop-blur-sm"
        >
          <span>{t('skip')}</span>
          <X className="h-4 w-4" />
        </button>
        
        {/* Progress indicator */}
        <div className="absolute top-4 left-4 flex gap-1.5">
          {steps.map((_, index) => (
            <div
              key={index}
              className={`h-2 w-8 rounded-full transition-colors ${
                index <= currentStep ? 'bg-white' : 'bg-white/30'
              }`}
            />
          ))}
        </div>
        
        {/* Tooltip */}
        <motion.div
          key={currentStep}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          className="onboarding-tooltip bottom-32 left-4 right-4"
        >
          <h3 className="mb-2 text-xl font-bold text-foreground">
            {t(`onboardingStep${currentStep + 1}` as any)}
          </h3>
          
          <div className="mt-4 flex items-center justify-between">
            <button
              onClick={prevStep}
              disabled={currentStep === 0}
              className={`flex items-center gap-1 rounded-xl px-4 py-2 font-medium transition-colors ${
                currentStep === 0 
                  ? 'text-muted-foreground opacity-50' 
                  : 'text-foreground hover:bg-muted'
              }`}
            >
              <ChevronLeft className="h-4 w-4" />
              <span>{t('skip')}</span>
            </button>
            
            <button
              onClick={isLastStep ? finishOnboarding : nextStep}
              className="btn-primary flex items-center gap-2 !py-2 !px-5"
            >
              <span>{isLastStep ? t('finish') : t('next')}</span>
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
