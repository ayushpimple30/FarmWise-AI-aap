import { motion } from 'framer-motion';
import { AlertTriangle, CheckCircle } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

interface SeverityBadgeProps {
  severity: 'low' | 'medium' | 'high';
  showIcon?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

export default function SeverityBadge({ severity, showIcon = true, size = 'md' }: SeverityBadgeProps) {
  const { t } = useLanguage();
  
  const config = {
    low: {
      label: t('severityLow'),
      className: 'severity-low',
      icon: CheckCircle
    },
    medium: {
      label: t('severityMedium'),
      className: 'severity-medium',
      icon: AlertTriangle
    },
    high: {
      label: t('severityHigh'),
      className: 'severity-high',
      icon: AlertTriangle
    }
  };
  
  const sizeClasses = {
    sm: 'px-2 py-1 text-xs',
    md: 'px-3 py-1.5 text-sm',
    lg: 'px-4 py-2 text-base'
  };
  
  const iconSizes = {
    sm: 'h-3 w-3',
    md: 'h-4 w-4',
    lg: 'h-5 w-5'
  };
  
  const { label, className, icon: Icon } = config[severity];
  
  return (
    <motion.span
      initial={{ scale: 0.9, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      className={`inline-flex items-center gap-1.5 font-semibold ${className} ${sizeClasses[size]}`}
    >
      {showIcon && <Icon className={iconSizes[size]} />}
      <span>{label}</span>
    </motion.span>
  );
}
