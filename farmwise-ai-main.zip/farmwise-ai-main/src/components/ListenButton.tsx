import { Volume2, VolumeX } from 'lucide-react';
import { useTTS } from '@/hooks/useTTS';
import { useLanguage } from '@/contexts/LanguageContext';
import { motion } from 'framer-motion';

interface ListenButtonProps {
  text: string;
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

export default function ListenButton({ text, className = '', size = 'md' }: ListenButtonProps) {
  const { t } = useLanguage();
  const { toggleSpeak, isSpeaking, isSupported } = useTTS();
  
  if (!isSupported) return null;
  
  const sizeClasses = {
    sm: 'px-3 py-1.5 text-sm gap-1.5',
    md: 'px-4 py-2 text-base gap-2',
    lg: 'px-5 py-3 text-lg gap-2.5'
  };
  
  const iconSizes = {
    sm: 'h-4 w-4',
    md: 'h-5 w-5',
    lg: 'h-6 w-6'
  };
  
  return (
    <motion.button
      whileTap={{ scale: 0.95 }}
      onClick={() => toggleSpeak(text)}
      className={`
        inline-flex items-center rounded-xl font-semibold transition-all
        ${isSpeaking 
          ? 'bg-red-100 text-red-700 hover:bg-red-200' 
          : 'bg-accent/10 text-accent hover:bg-accent/20'
        }
        ${sizeClasses[size]}
        ${className}
      `}
    >
      {isSpeaking ? (
        <>
          <VolumeX className={`${iconSizes[size]} animate-pulse`} />
          <span>{t('stopListening')}</span>
        </>
      ) : (
        <>
          <Volume2 className={iconSizes[size]} />
          <span>{t('listen')}</span>
        </>
      )}
    </motion.button>
  );
}
