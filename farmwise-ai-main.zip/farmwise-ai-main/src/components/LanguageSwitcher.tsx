import { useLanguage } from '@/contexts/LanguageContext';
import { Language } from '@/lib/i18n';
import { motion } from 'framer-motion';

export default function LanguageSwitcher() {
  const { language, setLanguage, t } = useLanguage();
  
  const languages: { code: Language; label: string }[] = [
    { code: 'en', label: t('english') },
    { code: 'hi', label: t('hindi') },
    { code: 'mr', label: t('marathi') },
  ];
  
  return (
    <div className="flex flex-wrap gap-2">
      {languages.map((lang) => (
        <motion.button
          key={lang.code}
          whileTap={{ scale: 0.95 }}
          onClick={() => setLanguage(lang.code)}
          className={`lang-btn ${language === lang.code ? 'active' : 'hover:bg-muted'}`}
        >
          {lang.label}
        </motion.button>
      ))}
    </div>
  );
}
