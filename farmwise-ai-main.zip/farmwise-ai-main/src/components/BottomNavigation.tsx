import { NavLink as RouterNavLink, useLocation } from 'react-router-dom';
import { Home, Scan, Clock, Cloud, Building2 } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { motion } from 'framer-motion';

const navItems = [
  { path: '/', icon: Home, labelKey: 'home' as const, onboardingId: 'home' },
  { path: '/history', icon: Clock, labelKey: 'history' as const, onboardingId: 'history' },
  { path: '/scan', icon: Scan, labelKey: 'scan' as const, onboardingId: 'scan' },
  { path: '/weather', icon: Cloud, labelKey: 'weather' as const, onboardingId: 'weather' },
  { path: '/schemes', icon: Building2, labelKey: 'schemes' as const, onboardingId: 'schemes' },
];

export default function BottomNavigation() {
  const location = useLocation();
  const { t } = useLanguage();
  
  return (
    <nav className="bottom-nav">
      {navItems.map((item) => {
        const isActive = location.pathname === item.path;
        const Icon = item.icon;
        const isScan = item.path === '/scan';
        
        return (
          <RouterNavLink
            key={item.path}
            to={item.path}
            data-onboarding={item.onboardingId}
            className="relative flex-1 flex justify-center"
          >
            {isScan ? (
              <motion.div
                whileTap={{ scale: 0.9 }}
                className={`
                  -mt-8 flex h-16 w-16 items-center justify-center rounded-full 
                  bg-primary text-primary-foreground shadow-lg
                  ${isActive ? 'ring-4 ring-primary/30' : ''}
                `}
              >
                <Icon className="h-7 w-7" />
              </motion.div>
            ) : (
              <motion.div
                whileTap={{ scale: 0.95 }}
                className={`nav-item ${isActive ? 'active' : ''}`}
              >
                <Icon className={`h-5 w-5 ${isActive ? 'text-primary' : ''}`} />
                <span className="text-xs font-medium">{t(item.labelKey)}</span>
              </motion.div>
            )}
          </RouterNavLink>
        );
      })}
    </nav>
  );
}
