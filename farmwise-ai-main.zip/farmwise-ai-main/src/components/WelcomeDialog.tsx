import { motion, AnimatePresence } from 'framer-motion';
import { useOnboarding } from '@/contexts/OnboardingContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { Leaf, HelpCircle } from 'lucide-react';

export default function WelcomeDialog() {
  const { shouldShowWelcome, dismissWelcome, acceptOnboarding } = useOnboarding();
  const { t } = useLanguage();
  
  if (!shouldShowWelcome) return null;
  
  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[150] flex items-center justify-center bg-black/60 p-4"
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="w-full max-w-sm rounded-3xl bg-card p-6 shadow-2xl"
        >
          {/* Icon */}
          <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-primary/10">
            <Leaf className="h-10 w-10 text-primary" />
          </div>
          
          {/* Title */}
          <h2 className="mb-2 text-center text-2xl font-bold text-foreground">
            {t('onboardingWelcome')}
          </h2>
          
          {/* Question */}
          <div className="mb-6 flex items-center justify-center gap-2 text-center text-muted-foreground">
            <HelpCircle className="h-5 w-5" />
            <p>{t('onboardingQuestion')}</p>
          </div>
          
          {/* Buttons */}
          <div className="flex gap-3">
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={dismissWelcome}
              className="flex-1 rounded-xl border-2 border-border bg-card px-4 py-3 font-semibold text-foreground transition-colors hover:bg-muted"
            >
              {t('no')}
            </motion.button>
            
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={acceptOnboarding}
              className="btn-primary flex-1"
            >
              {t('yes')}
            </motion.button>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
