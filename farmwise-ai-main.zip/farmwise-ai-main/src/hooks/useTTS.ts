import { useState, useCallback } from 'react';
import { speak, stop, getIsSpeaking, isTTSSupported } from '@/lib/tts';
import { useLanguage } from '@/contexts/LanguageContext';

export function useTTS() {
  const { language } = useLanguage();
  const [isSpeaking, setIsSpeaking] = useState(false);
  
  const speakText = useCallback(async (text: string) => {
    if (!isTTSSupported()) {
      console.warn('TTS not supported in this browser');
      return;
    }
    
    try {
      setIsSpeaking(true);
      await speak(text, language);
    } catch (error) {
      console.error('TTS error:', error);
    } finally {
      setIsSpeaking(false);
    }
  }, [language]);
  
  const stopSpeaking = useCallback(() => {
    stop();
    setIsSpeaking(false);
  }, []);
  
  const toggleSpeak = useCallback(async (text: string) => {
    if (getIsSpeaking()) {
      stopSpeaking();
    } else {
      await speakText(text);
    }
  }, [speakText, stopSpeaking]);
  
  return {
    speakText,
    stopSpeaking,
    toggleSpeak,
    isSpeaking,
    isSupported: isTTSSupported()
  };
}
