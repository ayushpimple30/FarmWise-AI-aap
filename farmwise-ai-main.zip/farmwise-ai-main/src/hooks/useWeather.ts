import { useState, useEffect, useCallback } from 'react';
import { 
  WeatherData, 
  getWeatherCache, 
  setWeatherCache, 
  isWeatherCacheValid 
} from '@/lib/storage';

// OpenWeather API (free tier)
const OPENWEATHER_API_KEY = ''; // Will need to be set by user or use a proxy

interface UseWeatherResult {
  weather: WeatherData | null;
  isLoading: boolean;
  error: string | null;
  isOffline: boolean;
  refetch: () => Promise<void>;
}

// Mock weather data for demo purposes
const getMockWeatherData = (): WeatherData => {
  const now = new Date();
  return {
    current: {
      temp: 28 + Math.floor(Math.random() * 8),
      humidity: 55 + Math.floor(Math.random() * 25),
      description: ['Partly Cloudy', 'Sunny', 'Clear Sky', 'Scattered Clouds'][Math.floor(Math.random() * 4)],
      icon: '02d',
      windSpeed: 8 + Math.floor(Math.random() * 12),
      rainProbability: Math.floor(Math.random() * 40)
    },
    forecast: Array.from({ length: 5 }, (_, i) => {
      const date = new Date(now);
      date.setDate(date.getDate() + i + 1);
      return {
        date: date.toISOString().split('T')[0],
        temp: 26 + Math.floor(Math.random() * 10),
        minTemp: 18 + Math.floor(Math.random() * 5),
        maxTemp: 30 + Math.floor(Math.random() * 8),
        description: ['Sunny', 'Partly Cloudy', 'Light Rain', 'Clear'][Math.floor(Math.random() * 4)],
        icon: ['01d', '02d', '10d', '01d'][Math.floor(Math.random() * 4)],
        rainProbability: Math.floor(Math.random() * 60)
      };
    }),
    location: 'Maharashtra, India'
  };
};

export function useWeather(): UseWeatherResult {
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isOffline, setIsOffline] = useState(false);
  
  const fetchWeather = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    
    // Check cache first
    if (isWeatherCacheValid()) {
      const cached = getWeatherCache();
      if (cached.data) {
        setWeather(cached.data);
        setIsLoading(false);
        return;
      }
    }
    
    // Check if online
    if (!navigator.onLine) {
      setIsOffline(true);
      const cached = getWeatherCache();
      if (cached.data) {
        setWeather(cached.data);
      } else {
        setError('No cached data available');
      }
      setIsLoading(false);
      return;
    }
    
    try {
      // For demo, use mock data
      // In production, replace with actual API call:
      // const response = await fetch(
      //   `https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&appid=${API_KEY}&units=metric`
      // );
      
      await new Promise(resolve => setTimeout(resolve, 800));
      const mockData = getMockWeatherData();
      
      setWeather(mockData);
      setWeatherCache(mockData);
      setIsOffline(false);
    } catch (err) {
      console.error('Weather fetch error:', err);
      
      // Try to use cached data
      const cached = getWeatherCache();
      if (cached.data) {
        setWeather(cached.data);
        setIsOffline(true);
      } else {
        setError('Failed to fetch weather data');
      }
    } finally {
      setIsLoading(false);
    }
  }, []);
  
  useEffect(() => {
    fetchWeather();
    
    // Listen for online/offline events
    const handleOnline = () => {
      setIsOffline(false);
      fetchWeather();
    };
    
    const handleOffline = () => {
      setIsOffline(true);
    };
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [fetchWeather]);
  
  return {
    weather,
    isLoading,
    error,
    isOffline,
    refetch: fetchWeather
  };
}

// Get farming advice based on weather
export function getFarmingAdvice(weather: WeatherData, lang: string = 'en'): {
  irrigation: string;
  spray: string;
  diseaseRisk: string;
  general: string;
} {
  const { current } = weather;
  
  const advice = {
    en: {
      irrigation: {
        low: 'Good conditions for irrigation. Water crops in the morning.',
        high: 'Rain expected. Reduce irrigation to prevent waterlogging.',
        moderate: 'Moderate watering recommended. Check soil moisture.'
      },
      spray: {
        safe: 'Safe to spray pesticides. Low wind conditions.',
        avoid: 'Avoid spraying. Rain or high wind expected.',
        caution: 'Spray early morning only. Wind may increase later.'
      },
      diseaseRisk: {
        low: 'Low disease risk. Continue monitoring.',
        medium: 'Moderate disease risk due to humidity. Watch for symptoms.',
        high: 'High disease risk! Humid conditions favor fungal growth.'
      },
      general: {
        hot: 'Hot weather ahead. Ensure adequate irrigation and shade for sensitive crops.',
        cool: 'Cool weather expected. Good for vegetable crops.',
        normal: 'Favorable conditions for most farming activities.'
      }
    },
    hi: {
      irrigation: {
        low: 'सिंचाई के लिए अच्छी स्थिति। सुबह फसलों को पानी दें।',
        high: 'बारिश की उम्मीद। जलभराव से बचने के लिए सिंचाई कम करें।',
        moderate: 'मध्यम पानी देने की सिफारिश। मिट्टी की नमी जांचें।'
      },
      spray: {
        safe: 'कीटनाशक छिड़काव के लिए सुरक्षित। कम हवा।',
        avoid: 'छिड़काव से बचें। बारिश या तेज हवा की उम्मीद।',
        caution: 'केवल सुबह जल्दी छिड़काव करें। बाद में हवा बढ़ सकती है।'
      },
      diseaseRisk: {
        low: 'रोग का कम जोखिम। निगरानी जारी रखें।',
        medium: 'आर्द्रता के कारण मध्यम रोग जोखिम। लक्षणों पर ध्यान दें।',
        high: 'उच्च रोग जोखिम! नम स्थिति फफूंद वृद्धि के लिए अनुकूल।'
      },
      general: {
        hot: 'आगे गर्म मौसम। पर्याप्त सिंचाई और संवेदनशील फसलों के लिए छाया सुनिश्चित करें।',
        cool: 'ठंडे मौसम की उम्मीद। सब्जी फसलों के लिए अच्छा।',
        normal: 'अधिकांश कृषि गतिविधियों के लिए अनुकूल स्थिति।'
      }
    },
    mr: {
      irrigation: {
        low: 'सिंचनासाठी चांगली परिस्थिती. सकाळी पिकांना पाणी द्या.',
        high: 'पावसाची अपेक्षा. पाणी साचणे टाळण्यासाठी सिंचन कमी करा.',
        moderate: 'मध्यम पाणी देण्याची शिफारस. मातीची ओलावा तपासा.'
      },
      spray: {
        safe: 'कीटकनाशक फवारणीसाठी सुरक्षित. कमी वारा.',
        avoid: 'फवारणी टाळा. पाऊस किंवा जोराचा वारा अपेक्षित.',
        caution: 'फक्त सकाळी लवकर फवारणी करा. नंतर वारा वाढू शकतो.'
      },
      diseaseRisk: {
        low: 'रोगाचा कमी धोका. निरीक्षण सुरू ठेवा.',
        medium: 'आर्द्रतेमुळे मध्यम रोग धोका. लक्षणांवर लक्ष ठेवा.',
        high: 'उच्च रोग धोका! दमट परिस्थिती बुरशी वाढीस अनुकूल.'
      },
      general: {
        hot: 'पुढे उष्ण हवामान. पुरेसे सिंचन आणि संवेदनशील पिकांसाठी सावली सुनिश्चित करा.',
        cool: 'थंड हवामानाची अपेक्षा. भाजीपाला पिकांसाठी चांगले.',
        normal: 'बहुतेक शेती कामांसाठी अनुकूल परिस्थिती.'
      }
    }
  };
  
  const langAdvice = advice[lang as keyof typeof advice] || advice.en;
  
  // Determine conditions
  const irrigationKey = current.rainProbability > 50 ? 'high' : current.rainProbability > 20 ? 'moderate' : 'low';
  const sprayKey = current.rainProbability > 40 || current.windSpeed > 20 ? 'avoid' : current.windSpeed > 15 ? 'caution' : 'safe';
  const diseaseKey = current.humidity > 80 ? 'high' : current.humidity > 60 ? 'medium' : 'low';
  const generalKey = current.temp > 35 ? 'hot' : current.temp < 18 ? 'cool' : 'normal';
  
  return {
    irrigation: langAdvice.irrigation[irrigationKey],
    spray: langAdvice.spray[sprayKey],
    diseaseRisk: langAdvice.diseaseRisk[diseaseKey],
    general: langAdvice.general[generalKey]
  };
}
