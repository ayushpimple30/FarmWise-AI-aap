import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { hasSeenOnboarding, setOnboardingSeen } from '@/lib/storage';

interface OnboardingStep {
  id: string;
  title: string;
  description: string;
  targetSelector: string;
  position: 'top' | 'bottom' | 'left' | 'right';
}

interface OnboardingContextType {
  isOnboardingActive: boolean;
  currentStep: number;
  steps: OnboardingStep[];
  startOnboarding: () => void;
  nextStep: () => void;
  prevStep: () => void;
  skipOnboarding: () => void;
  finishOnboarding: () => void;
  shouldShowWelcome: boolean;
  dismissWelcome: () => void;
  acceptOnboarding: () => void;
}

const OnboardingContext = createContext<OnboardingContextType | undefined>(undefined);

const ONBOARDING_STEPS: OnboardingStep[] = [
  {
    id: 'home',
    title: 'onboardingStep1',
    description: 'home',
    targetSelector: '[data-onboarding="home"]',
    position: 'bottom'
  },
  {
    id: 'scan',
    title: 'onboardingStep2',
    description: 'scan',
    targetSelector: '[data-onboarding="scan"]',
    position: 'bottom'
  },
  {
    id: 'history',
    title: 'onboardingStep3',
    description: 'history',
    targetSelector: '[data-onboarding="history"]',
    position: 'top'
  },
  {
    id: 'weather',
    title: 'onboardingStep4',
    description: 'weather',
    targetSelector: '[data-onboarding="weather"]',
    position: 'top'
  },
  {
    id: 'schemes',
    title: 'onboardingStep5',
    description: 'schemes',
    targetSelector: '[data-onboarding="schemes"]',
    position: 'top'
  }
];

export function OnboardingProvider({ children }: { children: ReactNode }) {
  const [isOnboardingActive, setIsOnboardingActive] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [shouldShowWelcome, setShouldShowWelcome] = useState(false);
  
  useEffect(() => {
    // Check if user has seen onboarding
    const seen = hasSeenOnboarding();
    if (!seen) {
      setShouldShowWelcome(true);
    }
  }, []);
  
  const startOnboarding = () => {
    setIsOnboardingActive(true);
    setCurrentStep(0);
  };
  
  const nextStep = () => {
    if (currentStep < ONBOARDING_STEPS.length - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      finishOnboarding();
    }
  };
  
  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };
  
  const skipOnboarding = () => {
    setIsOnboardingActive(false);
    setOnboardingSeen(true);
  };
  
  const finishOnboarding = () => {
    setIsOnboardingActive(false);
    setOnboardingSeen(true);
  };
  
  const dismissWelcome = () => {
    setShouldShowWelcome(false);
    setOnboardingSeen(true);
  };
  
  const acceptOnboarding = () => {
    setShouldShowWelcome(false);
    startOnboarding();
  };
  
  return (
    <OnboardingContext.Provider
      value={{
        isOnboardingActive,
        currentStep,
        steps: ONBOARDING_STEPS,
        startOnboarding,
        nextStep,
        prevStep,
        skipOnboarding,
        finishOnboarding,
        shouldShowWelcome,
        dismissWelcome,
        acceptOnboarding
      }}
    >
      {children}
    </OnboardingContext.Provider>
  );
}

export function useOnboarding() {
  const context = useContext(OnboardingContext);
  if (!context) {
    throw new Error('useOnboarding must be used within an OnboardingProvider');
  }
  return context;
}
